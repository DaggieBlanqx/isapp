
document.addEventListener("deviceready",onDeviceReady,false);

function onDeviceReady(){

	var element = document.getElementById('model');

	element.InnerHTML = 'device model:' + device.model;
/*
$('#btn_device_details').click(function(){

		alert("READY");

		console.log("READY TO GO");

	$('#model').html(device.model);

    	console.log("hello" + device.model);

    	$('#platform').html(device.platform);

    	$('#uuid').html(device.uuid);

    	$('#version').html(device.version);

    	$('#manufacturer').html(device.manufacturer);

    	$('#isVirtual').html(device.isVirtual);

    	$('#serial').html(device.serial);


	});
*/
}