$(document).ready(function(){
 
	var platform = "Android";
	var updateChecks = "Platform="+platform+"&updateChecks=";
  var myVersion = 1.0;

	$.ajax({
                      type: "POST",/*
                      *our data will be submitted via a POST request
                      */
                      url:"http://dashboard.iship.co.ke/api/versioncheck.php",/*
                      *this is the Server API that will recieve our data
                      */
                      data: updateChecks,/*
                      *this is the variable that carries our data-it is the datastring
                      */
                      crossDomain: true,/*
                      *crossdomain allows us to operate beyond our domain eg server redirection to another domain 
                      */
                      cache: false,
                      /*
                      *we want our data to be of the most recent result so we set cache to false
                      */
                      beforeSend: function(){ 
                      	$("#signIn").val('checking for updates...');/*
                         *when the user clicks submit and all the required conditions from above have been met,the button will show a progress
                         */
                       },
                      success: function(data){/*
                      *the data in the function is simply the data that the server api sends back
                      */
                        if(data =="success"){
                               alert("Update is available!Better user experience");
                               alert("Download a new version of iShip on http://iship.co.ke/app");
                               window.location.replace("updates.html");
                              // $("#insert").val('submit');
                     /*
                      *when the data recieved is a success,user account has been authenticated
                      *the user is taken to the dashboard
                      */
                        }else if(data=="error"){
                      /*
                      *when the data received is error ,user account has not authenticated.
                      *the user sees an error alert "Sorry,authentication failed!"
                      *the user sees an error message that suggests 3 solutions
                      -either reset password,sign up or contact Support team
                      *the html code to be displayed has been put inside variables so as to result into a neater code.
                      *the html is  continuous,ie every tag opened has been closed respectively when displayed and therefore
                      *we display our result through the variables
                      */
                               alert("Sorry,authentication failed!");
                               var errorSignIn = '<span class="blanqxcenter"><p>It seems you have encountered an error when signing in.<br>It is possible that your account does not exist.Contact us if trouble persists';
                               var forgot = '<br><button id="forgot" class="blanqxcenter mdl-button  mdl-js-button mdl-button--primary mdl-js-ripple-effect">Forgot Password</button>';
                               var SignUp = '<button id="SignUp" class="blanqxcenter mdl-button  mdl-js-button mdl-button--primary mdl-js-ripple-effect">Sign Up</button><p></span>';

                               $("#brand").html(errorSignIn + forgot + SignUp);/*
                      *the html displayed has buttons
                      *I have attached eventliseners to the buttons
                      *the window.location.replace() simply aids in navigation of pages
                      */

                               $("#forgot").click(function(){
                               	window.location.replace("reset-pass.html");
                               }); 
                               $("#SignUp").click(function(){
                               	window.location.replace("signup.html");
                               });
                        }
                       }
                  });
});