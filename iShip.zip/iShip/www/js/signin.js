document.addEventListener("deviceready",onDeviceReady,false);

function onDeviceReady(){

 document.AddEventlistener("online",chkOnline,false);
 document.AddEventlistener("offline",chkOffline,false);

 function chkOnline(){
	//user is online therefore we will not prompt him/her to do any action
 }

 function chkOffline(){
	//user is offine so we will give user an alert to warn him/her that data will not be sent over the internet
	alert("Sorry ,there is no internet connection!iShip requires an internet connection.");
 }
}
$(document).ready(function(){

	$("#email").keyup(function(){
		var email= $("#email").val();
		$("#myemail").html(email);
	});
	$("#phoneNumber").keyup(function(){
		var phoneNumber= $("#phoneNumber").val();
		$("#myphone").html(phoneNumber);
	});


	$("#SignIn").click(function(){
		/*
		*the code that follows simply wait for the event listener onclick.
		*when the user clicks submit the values in input boxes are parsed into their respective 9variables
		*/
      var email = $("#email").val();
      var phoneNumber = $("#phoneNumber").val();
      var password = $("#password").val();
		/*
		*here below we trim out whitespaces in the parsed data in the variables 
		*/

      var email = $.trim(email);
      var phoneNumber = $.trim(phoneNumber);
      var password = $.trim(password);
		/*
		*the two lines below are for API usage analytics when we want to know the user device and the role they play in our program
		*/
      var source = "Android";
      var role = "Shipper";
       /*
		*the code below now puts the variables that we have collected into a datastring which we will then send to our server as post data.
		*/

      var signUpData ="Email="+email+"&PhoneNumber="+phoneNumber+"&Pwd="+password+"&Source="+source+"&Role="+role+"&SignIn=";
		/*
		*the code below will only execute if the user has entered data that has been trimmed and found to have now white spaces
		*if the data is found trimmed and the result is empty input,the data submmission will not occur and instead the user will get
		-an alert telling him/her "Please ensure you have filled up the entire form"
		*/


      if (email.length>0 & phoneNumber.length>0) {
          $.ajax({
                      type: "POST",/*
                      *our data will be submitted via a POST request
                      */
                      url:"http://dashboard.iship.co.ke/api/login.php",/*
                      *this is the Server API that will recieve our data
                      */
                      data: signUpData,/*
                      *this is the variable that carries our data-it is the datastring
                      */
                      crossDomain: true,/*
                      *crossdomain allows us to operate beyond our domain eg server redirection to another domain 
                      */
                      cache: false,
                      /*
                      *we want our data to be of the most recent result so we set cache to false
                      */
                      beforeSend: function(){ 
                      	$("#signIn").val('authenticating...');/*
                         *when the user clicks submit and all the required conditions from above have been met,the button will show a progress
                         */
                       },
                      success: function(data){/*
                      *the data in the function is simply the data that the server api sends back
                      */
                        if(data=="success"){
                               alert("Authentication succesful!");
                               window.location.replace("dashboard.html");
                              // $("#insert").val('submit');
                     /*
                      *when the data recieved is a success,user account has been authenticated
                      *the user is taken to the dashboard
                      */
                        }else if(data=="error"){
                      /*
                      *when the data received is error ,user account has not authenticated.
                      *the user sees an error alert "Sorry,authentication failed!"
                      *the user sees an error message that suggests 3 solutions
                      -either reset password,sign up or contact Support team
                      *the html code to be displayed has been put inside variables so as to result into a neater code.
                      *the html is  continuous,ie every tag opened has been closed respectively when displayed and therefore
                      *we display our result through the variables
                      */
                               alert("Sorry,authentication failed!");
                               var errorSignIn = '<span class="blanqxcenter"><p>It seems you have encountered an error when signing in.<br>It is possible that your account does not exist.Contact us if trouble persists';
                               var forgot = '<br><button id="forgot" class="blanqxcenter mdl-button  mdl-js-button mdl-button--primary mdl-js-ripple-effect">Forgot Password</button>';
                               var SignUp = '<button id="SignUp" class="blanqxcenter mdl-button  mdl-js-button mdl-button--primary mdl-js-ripple-effect">Sign Up</button><p></span>';

                               $("#brand").html(errorSignIn + forgot + SignUp);/*
                      *the html displayed has buttons
                      *I have attached eventliseners to the buttons
                      *the window.location.replace() simply aids in navigation of pages
                      */

                               $("#forgot").click(function(){
                               	window.location.replace("reset-pass.html");
                               }); 
                               $("#SignUp").click(function(){
                               	window.location.replace("signup.html");
                               });
                        }
                       }
                  });

      }else{
      	/*
      	*when user submits unfilled form,this is executed
      	*/
      	alert("Please ensure you have filled up the entire form")
      }
    });
});