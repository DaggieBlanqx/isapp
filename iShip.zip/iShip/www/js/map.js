     var map = null;
      var directionDisplay;
      var directionsService = new google.maps.DirectionsService();

      function initialize() {
        directionsDisplay = new google.maps.DirectionsRenderer();
        var mapOptions = {
          zoom: 7,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          
          center: new google.maps.LatLng(1.2921, 36.8219)
       //centered map to kenya
        };
        map = new google.maps.Map(document.getElementById('map_canvas'),
            mapOptions);

    //Find PickUp location    
    var fromText = document.getElementById('pickUpPoint');
    var fromAuto = new google.maps.places.Autocomplete(fromText);
    fromAuto.bindTo('bounds', map);
    //Find DropOff location
    var toText = document.getElementById('dropOffPoint');
    var toAuto = new google.maps.places.Autocomplete(toText);
    toAuto.bindTo('bounds', map);
        directionsDisplay.setMap(map);
        directionsDisplay.setPanel(document.getElementById('directions-panel'));

        var control = document.getElementById('control');
        control.style.display = 'block';
        map.controls[google.maps.ControlPosition.TOP].push(control);
      }

      function calcRoute() {
        var start = document.getElementById('pickUpPoint').value;
        var end = document.getElementById('dropOffPoint').value;
        var request = {
          origin: start,
          destination: end,
          travelMode: google.maps.DirectionsTravelMode.DRIVING
        };
        directionsService.route(request, function(response, status) {
          if (status == google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
            computeTotalDistance(response);
           // computeTotalEstimate(response);
          }
        });
      }
      function computeTotalDistance(result) {
      var total = 0;
      var estimate;
      var myroute = result.routes[0];
      for (i = 0; i < myroute.legs.length; i++) {
        total += myroute.legs[i].distance.value;
      }
      total = total / 1000.

      estimate = total*100;
      document.getElementById("estimate").innerHTML = "kes" + estimate;
      document.getElementById("total").innerHTML = total + " km";
      }
/*
      function computeTotalEstimate(result){
        var total;
        var estimate;
        //rate 1km = kes100
        estimate = total*100;
        document.getElementById("estimate").innerHTML = "kes" + estimate;
      }
*/
    function auto() {
    var input = document.getElementById[('start'), ('end')];
    var types
    var options = {
       types: [],
       componentRestrictions: {country: ["KE"]}
        };
        var autocomplete = new google.maps.places.Autocomplete(input, options);
     }

      google.maps.event.addDomListener(window, 'load', initialize);