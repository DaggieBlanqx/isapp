 $(document).ready(function()
 {
 	$("#insert").click(function(){
      var title= $("#title").val();
      var duration= $("#duration").val();
      var price= $("#price").val();
      var dataString="title="+title+"&duration="+duration+"&price="+price+"&insert=";
    //  $("#para").html(dataString);
      if($.trim(title).length>0 & $.trim(duration).length>0 & $.trim(price).length>0)
           {
              $.ajax({
                      type: "POST",
                      url:"http://localhost/phonegap/insert.php",
                      data: dataString,
                      crossDomain: true,
                      cache: false,
                      beforeSend: function(){ 
                      	$("#insert").val('Connecting...');
                       },
                      success: function(data){
                        if(data=="success"){
                               alert("inserted");
                               $("#insert").val('submit');
                        }else if(data=="error"){
                               alert("error");
                        }
                       }
                    });
            }
            return false;
  });
});